import React, { useEffect, useRef } from "react";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  useMapEvents,
  Polyline,
} from "react-leaflet";
import L from "leaflet";
import "leaflet-routing-machine/dist/leaflet-routing-machine.css";
import "leaflet/dist/leaflet.css";
import "./App.css";
import { fetchRouteGraph } from "./routeToGraph";
import { dfs, bfs, dijkstra, astar } from "./algorithms";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const greenIcon = new L.Icon({
  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

const redIcon = new L.Icon({
  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

// Only mounts after the algorithm has found a path — not on marker placement
function RoutingControl({ source, destination }) {
  const map = useMapEvents({});
  const routingRef = useRef(null);

  useEffect(() => {
    if (!source || !destination) return;
    if (routingRef.current) {
      map.removeControl(routingRef.current);
      routingRef.current = null;
    }
    import("leaflet-routing-machine").then(() => {
      routingRef.current = L.Routing.control({
        waypoints: [
          L.latLng(source.lat, source.lng),
          L.latLng(destination.lat, destination.lng),
        ],
        routeWhileDragging: false,
        addWaypoints: false,
        createMarker: () => null,
        lineOptions: {
          styles: [{ color: "#F97316", opacity: 0.9, weight: 5 }],
        },
      }).addTo(map);
    });
    return () => {
      if (routingRef.current) {
        map.removeControl(routingRef.current);
        routingRef.current = null;
      }
    };
  }, [source, destination, map]);

  return null;
}

function ClickHandler({ onSourceSet, onDestinationSet, mode }) {
  useMapEvents({
    click(e) {
      const { lat, lng } = e.latlng;
      if (mode === "source") onSourceSet({ lat, lng });
      else if (mode === "destination") onDestinationSet({ lat, lng });
    },
  });
  return null;
}

const App = () => {
  const [source, setSource] = React.useState(null);
  const [destination, setDestination] = React.useState(null);
  const [mode, setMode] = React.useState("source");

  // Each entry is a 2-point array [[latA,lngA],[latB,lngB]] — one edge of the exploration tree
  const [exploredEdges, setExploredEdges] = React.useState([]);

  // Set only after animation finishes — this is what triggers RoutingControl to mount
  const [pathFound, setPathFound] = React.useState(false);

  const [algorithm, setAlgorithm] = React.useState("dijkstra");
  const animationRef = React.useRef([]);

  // Cache the graph between "Run" calls so we don't re-fetch on algorithm change
  const graphCache = React.useRef(null);

  const runAlgorithm = async () => {
    animationRef.current.forEach(clearTimeout);
    setExploredEdges([]);
    setPathFound(false);

    // Fetch graph only if not already cached for this source/destination pair
    if (!graphCache.current) {
      graphCache.current = await fetchRouteGraph(source, destination);
    }

    const { graph, nodes, startKey, endKey } = graphCache.current;

    let result;
    if (algorithm === "dfs") result = dfs(graph, startKey, endKey);
    else if (algorithm === "bfs") result = bfs(graph, startKey, endKey);
    else if (algorithm === "astar")
      result = astar(graph, nodes, startKey, endKey);
    else result = dijkstra(graph, startKey, endKey);

    const { visitedOrder, parent } = result;
    const DELAY = 30;

    // Animate one edge per visited node — connect each node back to its parent
    animationRef.current = visitedOrder.map((key, i) =>
      setTimeout(() => {
        const parentKey = parent[key];
        if (!parentKey) return; // start node has no parent

        const [latA, lngA] = parentKey.split(",").map(Number);
        const [latB, lngB] = key.split(",").map(Number);

        setExploredEdges((prev) => [
          ...prev,
          [
            [latA, lngA],
            [latB, lngB],
          ],
        ]);
      }, i * DELAY),
    );

    // After all edges are drawn, trigger the final route via RoutingControl
    setTimeout(
      () => {
        setPathFound(true);
      },
      visitedOrder.length * DELAY + 200,
    );
  };

  const reset = () => {
    animationRef.current.forEach(clearTimeout);
    graphCache.current = null;
    setSource(null);
    setDestination(null);
    setMode("source");
    setExploredEdges([]);
    setPathFound(false);
  };

  const handleSourceSet = (latlng) => {
    setSource(latlng);
    setMode("destination");
  };

  const handleDestinationSet = (latlng) => {
    // Clear cache whenever a new destination is chosen
    graphCache.current = null;
    setDestination(latlng);
    setMode("done");
  };

  return (
    <div className="app-wrapper">
      <div className="controls">
        {mode === "source" && (
          <p>
            📍 Click the map to set <strong>source</strong>
          </p>
        )}
        {mode === "destination" && (
          <p>
            🏁 Click the map to set <strong>destination</strong>
          </p>
        )}
        {mode === "done" && (
          <>
            <select
              value={algorithm}
              onChange={(e) => setAlgorithm(e.target.value)}
            >
              <option value="dfs">DFS</option>
              <option value="bfs">BFS</option>
              <option value="dijkstra">Dijkstra</option>
              <option value="astar">A*</option>
            </select>
            <button onClick={runAlgorithm}>▶ Run</button>
            <button onClick={reset}>↺ Reset</button>
          </>
        )}
      </div>

      <MapContainer
        center={[51.505, -0.09]}
        zoom={13}
        scrollWheelZoom={true}
        className="mapc"
      >
        <TileLayer
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        <ClickHandler
          onSourceSet={handleSourceSet}
          onDestinationSet={handleDestinationSet}
          mode={mode}
        />

        {source && (
          <Marker position={[source.lat, source.lng]} icon={greenIcon}>
            <Popup>Source</Popup>
          </Marker>
        )}
        {destination && (
          <Marker position={[destination.lat, destination.lng]} icon={redIcon}>
            <Popup>Destination</Popup>
          </Marker>
        )}

        {/* Exploration tree — drawn edge by edge as the algorithm runs */}
        {/* Exploration edges — dim amber, like unlit roads */}
        {exploredEdges.map((edge, i) => (
          <Polyline
            key={i}
            positions={edge}
            pathOptions={{
              color: "#b84f00",
              weight: 2,
              opacity: 0.5,
            }}
          />
        ))}

        {/* Final route — bright glowing orange on top */}
        {pathFound && source && destination && (
          <RoutingControl source={source} destination={destination} />
        )}
      </MapContainer>
    </div>
  );
};

export default App;
